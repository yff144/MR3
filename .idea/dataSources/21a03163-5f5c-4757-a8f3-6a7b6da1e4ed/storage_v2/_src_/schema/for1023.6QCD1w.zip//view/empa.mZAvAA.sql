CREATE VIEW empa AS
  SELECT
    `a`.`empno`                                   AS `empno`,
    `a`.`ename`                                   AS `ename`,
    `a`.`job`                                     AS `job`,
    (SELECT `for1023`.`emp`.`ename`
     FROM `for1023`.`emp`
     WHERE (`for1023`.`emp`.`empno` = `a`.`mgr`)) AS `mgrname`,
    (SELECT (CASE WHEN (`a`.`sal` < 1000)
      THEN 'A'
             WHEN ((`a`.`sal` >= 1000) AND (`a`.`sal` < 2000))
               THEN 'B'
             ELSE 'C' END))                       AS `sal`,
    `b`.`dname`                                   AS `dname`
  FROM (`for1023`.`emp` `a` LEFT JOIN `for1023`.`dept` `b` ON ((`a`.`deptno` = `b`.`deptno`)));

